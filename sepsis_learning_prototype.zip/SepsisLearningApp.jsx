import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function SepsisLearningApp() {
  const [quizAnswer, setQuizAnswer] = useState("");
  const [result, setResult] = useState("");
  const [caseAnswer, setCaseAnswer] = useState("");
  const [caseResult, setCaseResult] = useState("");
  const [case2Answer, setCase2Answer] = useState("");
  const [case2Result, setCase2Result] = useState("");
  const [score, setScore] = useState(0);
  const [summary, setSummary] = useState("");

  const handleQuizSubmit = () => {
    if (quizAnswer.trim().toLowerCase() === "3 ชั่วโมง") {
      setResult("✅ ถูกต้อง! การให้ยาปฏิชีวนะภายใน 3 ชั่วโมงเป็นมาตรฐานเบื้องต้นในการดูแลผู้ป่วย sepsis.");
      setScore((prev) => prev + 1);
    } else {
      setResult("❌ คำตอบไม่ถูกต้อง ลองทบทวนเนื้อหาอีกครั้ง");
    }
  };

  const handleCaseSubmit = () => {
    if (caseAnswer.toLowerCase().includes("ให้สารน้ำ") && caseAnswer.toLowerCase().includes("ให้ยาปฏิชีวนะ")) {
      setCaseResult("✅ เยี่ยมมาก! คุณวางแผนการดูแลได้ถูกต้องตามแนวทาง initial sepsis management.");
      setScore((prev) => prev + 1);
    } else {
      setCaseResult("❌ ยังไม่ครบถ้วน ลองเพิ่มขั้นตอนการดูแลเช่น การให้สารน้ำและยาปฏิชีวนะทันที");
    }
  };

  const handleCase2Submit = () => {
    if (
      case2Answer.toLowerCase().includes("วัดแลคเตท") &&
      case2Answer.toLowerCase().includes("ติดตามความดัน")
    ) {
      setCase2Result("✅ ถูกต้อง! ต้องวัดระดับ lactate ซ้ำและประเมินความตอบสนองต่อการรักษา");
      setScore((prev) => prev + 1);
    } else {
      setCase2Result("❌ คำตอบยังไม่ครบ ลองพิจารณาแนวทางติดตามผลหลังให้สารน้ำ");
    }
  };

  const handleShowSummary = () => {
    setSummary(`คะแนนรวมของคุณคือ ${score}/3`);
  };

  const handleReset = () => {
    setQuizAnswer("");
    setResult("");
    setCaseAnswer("");
    setCaseResult("");
    setCase2Answer("");
    setCase2Result("");
    setScore(0);
    setSummary("");
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">Sepsis & Septic Shock Learning App</h1>

      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Module 1: ความรู้เบื้องต้นเกี่ยวกับ Sepsis</h2>
          <p>
            Sepsis คือภาวะที่ร่างกายตอบสนองต่อการติดเชื้ออย่างรุนแรงจนทำให้อวัยวะสำคัญล้มเหลวได้
            ผู้ป่วยต้องได้รับการวินิจฉัยและให้การรักษาทันที เช่น ให้สารน้ำ ยาปฏิชีวนะ และติดตามอาการอย่างใกล้ชิด
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Module 2: แนวทางการเรียนรู้ตาม KAP Model</h2>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Knowledge (K):</strong> ทำความเข้าใจ Sepsis, แนวทาง Surviving Sepsis Campaign</li>
            <li><strong>Attitude (A):</strong> ตระหนักถึงความสำคัญของ Early Recognition & Early Treatment</li>
            <li><strong>Practice (P):</strong> การประเมินผู้ป่วยด้วย qSOFA/SOFA และการดำเนินการตามลำดับ</li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Module 3: แบบทดสอบ</h2>
          <p>ควรให้ยาปฏิชีวนะแก่ผู้ป่วย sepsis ภายในเวลากี่ชั่วโมงหลังจากเริ่มสงสัยภาวะติดเชื้อ?</p>
          <Input
            placeholder="กรอกคำตอบ เช่น 3 ชั่วโมง"
            value={quizAnswer}
            onChange={(e) => setQuizAnswer(e.target.value)}
          />
          <Button onClick={handleQuizSubmit}>ส่งคำตอบ</Button>
          {result && <p className="mt-2 font-medium">{result}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Module 4: สถานการณ์จำลอง (Case 1)</h2>
          <p>
            ผู้ป่วยชายอายุ 68 ปี มีไข้สูง 39.5°C ความดันโลหิตต่ำ 85/50 mmHg ชีพจรเร็ว หายใจเร็ว ซึมลง
            จากประวัติ มีแผลกดทับติดเชื้อที่สะโพกข้างซ้าย
            <br />
            <strong>คำถาม:</strong> คุณจะวางแผนการดูแลเบื้องต้นอย่างไร?
          </p>
          <Textarea
            placeholder="พิมพ์คำตอบของคุณ เช่น ให้สารน้ำ, เจาะเลือด, ให้ยาปฏิชีวนะ..."
            value={caseAnswer}
            onChange={(e) => setCaseAnswer(e.target.value)}
          />
          <Button onClick={handleCaseSubmit}>ส่งคำตอบ</Button>
          {caseResult && <p className="mt-2 font-medium">{caseResult}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Module 5: สถานการณ์จำลอง (Case 2)</h2>
          <p>
            ผู้ป่วยได้รับสารน้ำ 30 mL/kg แล้ว ความดันยังต่ำเล็กน้อย ซึมเล็กน้อย
            <br />
            <strong>คำถาม:</strong> คุณควรติดตามอะไรต่อเป็นลำดับถัดไป?
          </p>
          <Textarea
            placeholder="พิมพ์คำตอบของคุณ เช่น วัด lactate ซ้ำ, ประเมิน perfusion, ติดตาม MAP..."
            value={case2Answer}
            onChange={(e) => setCase2Answer(e.target.value)}
          />
          <Button onClick={handleCase2Submit}>ส่งคำตอบ</Button>
          {case2Result && <p className="mt-2 font-medium">{case2Result}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-4 text-center">
          <Button onClick={handleShowSummary}>ดูคะแนนสรุปผลการเรียนรู้</Button>
          {summary && <p className="mt-2 text-lg font-bold">{summary}</p>}
          <div className="mt-4">
            <Button variant="outline" onClick={handleReset}>
              รีเซ็ตคำตอบทั้งหมด
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
